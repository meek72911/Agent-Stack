#!/usr/bin/env node
/**
 * AgentStack Advanced Self-Healer
 * 
 * Functions:
 * 1. Analyzes Playwright JSON reports
 * 2. Extracts exact error snippets
 * 3. Identifies A11y and Visual Diff violations
 * 4. Generates a 'Smart Prompt' for AI-assisted healing
 */

const fs = require('fs');
const path = require('path');

const REPORT_PATH = 'tests/reports/results.json';
const HEAL_PROMPT_PATH = 'tests/reports/HEAL-PROMPT.md';

function main() {
  console.log('🔍 Analyzing Deep Scan results...\n');

  if (!fs.existsSync(REPORT_PATH)) {
    console.log('❌ No scan results found. Run: npx playwright test --project chromium');
    process.exit(1);
  }

  const results = JSON.parse(fs.readFileSync(REPORT_PATH, 'utf8'));
  const failures = [];

  const walkSuites = (suites) => {
    for (const suite of suites) {
      if (suite.specs) {
        for (const spec of suite.specs) {
          for (const test of spec.tests || []) {
            for (const result of test.results || []) {
              if (result.status === 'failed') {
                failures.push({
                  title: spec.title,
                  file: spec.file,
                  error: result.error?.message || 'Unknown error',
                  snippet: result.error?.snippet || '',
                  duration: result.duration,
                });
              }
            }
          }
        }
      }
      if (suite.suites) walkSuites(suite.suites);
    }
  };

  walkSuites(results.suites || []);

  if (failures.length === 0) {
    console.log('✅ UI Health is perfect! No healing required.');
    return;
  }

  console.log(`❌ Found ${failures.length} issues in the UI baseline.\n`);

  // Generate the Smart Healer Prompt
  const prompt = `# 🔧 AgentStack Self-Heal Prompt
Generated: ${new Date().toISOString()}

## 🚨 MISSION: Fix UI Baseline Failures
You are an autonomous UI engineer. Read the following test failures and **FIX them** in the codebase.

### Instructions:
1. **Analyze**: Read each error below carefully.
2. **Context**: Check the page file (e.g., apps/dashboard/app/...) corresponding to the test title.
3. **Fix**: 
   - If it's a **Selector Change**: Update the test in 'tests/ui/health-check.spec.ts' to match the new UI.
   - If it's a **Functional Bug**: Fix the actual React component/page.
   - If it's an **A11y Violation**: Fix the accessibility issue (missing labels, low contrast, etc.).
4. **Tool Use**: Use 'replace_file_content' or 'multi_replace_file_content' to apply the fixes.

---

## 🛑 FAILURES (${failures.length})

${failures.map((f, i) => `
### FAILURE ${i + 1}: ${f.title}
- **Location**: ${f.file}
- **Short Error**: ${f.error.split('\n')[0]}
- **Code Reference**:
\`\`\`typescript
${f.snippet || '// No snippet available'}
\`\`\`

**Healing Goal**: Fix the test or the component to pass the next run.
`).join('\n---\n')}

---

## NEXT STEP:
Say "Read heal prompt and fix all issues" to begin the autonomous repair cycle.
`;

  fs.writeFileSync(HEAL_PROMPT_PATH, prompt);
  console.log(`📝 HEAL-PROMPT.md generated!`);
  console.log(`\n👉 Say: "Read ${HEAL_PROMPT_PATH} and fix all issues"`);
}

main();
