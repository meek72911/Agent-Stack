---
name: AgentStack UI Testing Skill
description: Enterprise-grade UI Testing with Playwright, Axe-core, and Visual Diffs.
---

# AgentStack UI Testing Skill

This skill provides a complete framework for automated UI health, accessibility, and visual checks.

## Main Components:
1.  **Playwright Config**: Multi-device, visual diff thresholds, session persistence.
2.  **Health Check Script**: Deep scanning for HTTP errors, A11y violations, and visual regressions.
3.  **Authentication Setup**: Performs login once per suite to test protected routes.
4.  **Self-Healer Loop**: Analyzes JSON results to generate AI-fix prompts.

## Usage:

### 🚀 Running the Scan
```bash
cd apps/dashboard
npx playwright test
```

### ♿ Checking Accessibility
The scan automatically checks for WCAG 2.1 compliance. If failures occur, check:
`tests/reports/health-deep-scan.json`

### 📸 Visual Regressions
If any UI element shifts by more than 200px or has a 0.2 threshold difference, the test will fail. Update baselines with:
```bash
npx playwright test --update-snapshots
```

### 🩹 Self-Healing failing tests
If tests fail due to UI changes:
1.  Run: `node tests/heal.js`
2.  Prompt: "Read tests/reports/HEAL-PROMPT.md and fix all failing tests"

## Best Practices
- **Isolation**: Use 'setup' project for auth to keep individual tests focused.
- **Resilience**: Always use 'force: true' clicks for elements behind animations.
- **Reporting**: Always check 'HEALTH-REPORT.md' for a human-readable summary.
